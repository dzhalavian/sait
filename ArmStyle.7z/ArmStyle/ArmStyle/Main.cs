﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArmStyle
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
            button6.Size = new Size(1, 1);
            // Set the location of the button to be outside the form's client area.
            button6.Location = new Point(Size.Height - -60, Size.Width + 30);
            // Set the AutoScroll property to true to provide scrollbars.
            AutoScroll = true;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Main_Load(object sender, EventArgs e)
        {

    }

        private void button3_Click(object sender, EventArgs e)
        {
            new NeW().Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new Login().Show();
            Hide();
        }
        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Registration().Show();
            Hide();
        }
    }
}
